from django.shortcuts import render

from django.shortcuts import render

def index(request):
    return render(request, "home.html")

from django.shortcuts import render
def index1(request):
    return render(request, "about.html")
# Create your views here.
